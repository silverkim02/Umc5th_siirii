export const tempResponseDTO = (data) => {
    return {"testString" : data};
}
export const flagResponseDTO = (flag) => {
    return {"flag" : flag};
}